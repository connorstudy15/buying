"""按场景配对的上下文评测报告；正文保留供复核，未知usage不当成0。"""
from __future__ import annotations
import argparse,json,math,random,re,statistics
from collections import defaultdict
from pathlib import Path
from scripts.eval.run_context import check_case


def percentile(values,p):
    return sorted(values)[max(0,math.ceil(len(values)*p)-1)] if values else None


def score(rows,cases):
    for row in rows:
        case=cases[row['case_id']]
        # 评测要求币种语义为CNY，人民币/RMB等价，不能误判为事实丢失。
        answer=re.sub(r'人民币|RMB','CNY',row['answer'],flags=re.I)
        if 'CNY' in case['contains'] and re.search(r'\d+(?:\.\d+)?\s*元',answer) and not re.search('日元|美元|欧元',answer):answer+=' CNY'
        checks=check_case(case,answer,[True]*row['current_calls'])
        if row['mode']=='long':checks['two_compactions']=len(row['compactions'])==2 and all(r.get('summary_changed') for r in row['compactions'])
        row['original_checks']=row['checks'];row['checks']=checks
        row['passed']=all(checks.values()) and row['error'] is None
    return rows


def paired_interval(rows,a,b,seed=20260909):
    grouped=defaultdict(lambda:defaultdict(list))
    for row in rows:grouped[row['case_id']][row['strategy']].append(int(row['passed']))
    diffs=[statistics.mean(v[b])-statistics.mean(v[a]) for v in grouped.values() if a in v and b in v]
    if not diffs:return None
    rng=random.Random(seed)
    samples=[statistics.mean(rng.choices(diffs,k=len(diffs))) for _ in range(2000)]
    return {'unit':'scenario','difference':statistics.mean(diffs),'ci95':[percentile(samples,.025),percentile(samples,.975)]}


def summarize(rows):
    result={}
    for strategy in sorted({r['strategy'] for r in rows}):
        subset=[r for r in rows if r['strategy']==strategy]
        known=all(r['input_tokens'] is not None for r in subset)
        longs=[r for r in subset if r['mode']=='long']
        business_latency=[u['elapsed_ms'] for r in subset for u in r['usage'] if u['kind']=='business']
        result[strategy]={'runs':len(subset),'passed':sum(r['passed'] for r in subset),'success_rate':statistics.mean(int(r['passed']) for r in subset),
            'input_tokens':sum(r['input_tokens'] for r in subset) if known else None,
            'long_input_tokens':sum(r['input_tokens'] for r in longs) if longs and all(r['input_tokens'] is not None for r in longs) else None,
            'model_calls':sum(r['model_calls'] for r in subset),'lookup_calls':sum(r['lookup_calls'] for r in subset),
            'scenario_latency_p50_ms':percentile([r['elapsed_ms'] for r in subset],.5),
            'scenario_latency_p95_ms':percentile([r['elapsed_ms'] for r in subset],.95),
            'business_model_latency_p95_ms':percentile(business_latency,.95),
            'ordinary_round_p95_ms':percentile([m['elapsed_ms'] for r in subset for m in r.get('round_metrics',[]) if not m['compacted']],.95),
            'mean_final_context_estimated_tokens':statistics.mean(r['final_context_estimated_tokens'] for r in subset) if all('final_context_estimated_tokens' in r for r in subset) else None,
            'mean_final_product_duplicate_ratio':statistics.mean(r['final_product_duplicate_ratio'] for r in subset if r.get('final_product_duplicate_ratio') is not None) if any(r.get('final_product_duplicate_ratio') is not None for r in subset) else None,
            'unknown_usage_runs':sum(r['input_tokens'] is None for r in subset)}
    return result


def main(args):
    cases={c['id']:c for c in json.loads(Path('eval/context/cases.json').read_text())}
    rows=score(json.loads((args.input/'results.json').read_text()),cases)
    manifest=json.loads((args.input/'manifest.json').read_text())
    summary=summarize(rows);split=manifest['split']
    report={'grading_version':'context-facts-v2-currency-alias','manifest':manifest,'summary':summary,'failures':[r for r in rows if not r['passed']], 'gate':'INCOMPLETE'}
    if split=='dev':
        # 正确率相同时，实际token优先；接近（一个场景的一次重复内）默认压力触发。
        best=max(s['success_rate'] for s in summary.values())
        pressure=summary.get('pressure')
        critical={'dev-sku','dev-cost','dev-current','dev-budget','dev-country'}
        safe=[name for name in summary if not any(r['strategy']==name and r['case_id'] in critical and not r['passed'] for r in rows)]
        eligible=safe or list(summary)
        best=max(summary[name]['success_rate'] for name in eligible)
        selected='pressure' if 'pressure' in eligible and pressure and best-pressure['success_rate']<=1/36+1e-12 else min(eligible,key=lambda k:(-summary[k]['success_rate'],summary[k]['input_tokens'] or float('inf'),summary[k]['scenario_latency_p95_ms']))
        report['timing_selection_rule']='先排除SKU/金额/当前状态/预算/国家关键事实失败；再比成功率，接近且无关键失败时默认pressure'
        report.update(selected_timing=selected,gate='DEV_COMPLETE' if manifest['completed']==108 and manifest.get('code_stable') else 'INCOMPLETE')
        report['paired_intervals']={s:paired_interval(rows,'pressure',s) for s in summary if s!='pressure'}
    else:
        a,c=summary.get('legacy',{}),summary.get('layered',{})
        ratio=1-c['long_input_tokens']/a['long_input_tokens'] if a.get('long_input_tokens') and c.get('long_input_tokens') else None
        new_failures=[]
        for row in rows:
            if row['strategy']=='layered' and not row['passed']:
                peers=[r for r in rows if r['strategy']=='legacy' and r['case_id']==row['case_id'] and r['repetition']==row['repetition']]
                if any(r['passed'] for r in peers):new_failures.append({'case_id':row['case_id'],'repetition':row['repetition']})
        latency_ratio=c['ordinary_round_p95_ms']/a['ordinary_round_p95_ms'] if a.get('ordinary_round_p95_ms') and c.get('ordinary_round_p95_ms') else None
        report.update(long_input_reduction=ratio,ordinary_round_latency_ratio=latency_ratio,new_failures=new_failures,paired_interval=paired_interval(rows,'legacy','layered'))
        # 场景夹具不是完整交易/线上延迟验收，任何关键回归阻断；不伪造通过。
        eligible=manifest['completed']==252 and manifest.get('code_stable') and c.get('success_rate',0)>=a.get('success_rate',1) and not new_failures and ratio is not None and ratio>=.25 and latency_ratio is not None and latency_ratio<=1.15
        report['gate']='NEEDS_PRODUCTION_ACCEPTANCE' if eligible else 'BLOCK'
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    lines=['# 上下文评测报告',f"\n阶段：{split}；门禁：{report['gate']}。",'\n|策略|通过/运行|累计输入token|模型调用|历史回查|场景P95毫秒|','|---|---:|---:|---:|---:|---:|']
    for name,s in summary.items():lines.append(f"|{name}|{s['passed']}/{s['runs']}|{s['input_tokens'] if s['input_tokens'] is not None else '未知'}|{s['model_calls']}|{s['lookup_calls']}|{s['scenario_latency_p95_ms']}|")
    lines+=['\n## 验证范围','真实模型与AgentScope执行；目录和当前状态为隔离、冻结夹具。快照场景从固定历史续答，长对话实际运行20轮、两次整理、一次数据库重建。交易写路径、真实检索和浏览器恢复另做集成回归。', '\n成本包含摘要与回查后模型调用；无美元单价时不声称节省金额。延迟包含网关排队，场景P95不能冒充买家普通轮P95。币种人民币/RMB规范化为CNY，其余精确字段按规则断言。', '\n失败样本及逐场景差异见 report.json。未通过门禁时保留 legacy。']
    if 'long_input_reduction' in report:lines.append(f"\n长对话输入下降：{report['long_input_reduction']}；按场景配对区间：{report['paired_interval']}。")
    (args.output/'report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['failures','manifest']},ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())
