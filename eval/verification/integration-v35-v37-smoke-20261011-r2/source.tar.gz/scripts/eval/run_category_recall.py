# -*- coding: utf-8 -*-
"""品类知识库（CategoryInsight）召回评测 —— 见教程 13-1 §5。

与商品检索评测共用 `scripts/eval/metrics.py`。旧数据仍按文档名评分；v3 数据同时按
稳定证据（source + section + quote）评分，避免把“命中文档但命错 chunk”算作成功。

    商品检索      标注单位 = product_id
    品类知识库    文档诊断 = source；正式真值 = section + 原文 quote

用法（项目根目录执行，需 embedding 凭据 + Qdrant）：

    uv run python scripts/eval/run_category_recall.py
    uv run python scripts/eval/run_category_recall.py --top-k 5
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import sys
import time
import uuid
from dataclasses import replace
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.infrastructure.rag.knowledge_retrieval import search_knowledge_with_trace
from app.application.retrieval.query_processor import QueryProcessor
from app.application.prompts.loader import load_prompts
from app.infrastructure.llm import create_chat_model
from app.infrastructure.rag.category_knowledge import (  # noqa: E402
    EVALUATION_KNOWLEDGE_DIR,
    build_evaluation_knowledge_base,
    verify_evaluation_knowledge_base,
    has_answerable_knowledge,
    policy_fact_status,
)
from app.infrastructure.settings import load_settings  # noqa: E402
from app.infrastructure.langfuse_config import LangfuseConfig  # noqa: E402
from app.infrastructure.tracing import setup_tracing, shutdown_tracing  # noqa: E402
from scripts.eval.metrics import (  # noqa: E402
    Aggregate,
    QueryResult,
    Thresholds,
    attach_partial_coverage_metrics,
    evaluate,
    gate,
    graded_ndcg_at_k,
    mrr,
    ndcg_at_k,
    precision_at_k,
    recall_at_k,
)
from scripts.eval.knowledge_evidence import matched_evidence_ids  # noqa: E402
from scripts.eval.langfuse_trace import EvaluationCaseTrace, result_attributes  # noqa: E402
from scripts.eval.run_manifest import (  # noqa: E402
    SPLITS, build_manifest, finish_manifest, manifest_report, select_cases,
    validate_baseline_selection, write_manifest,
)

_DATASET = Path("eval/category_recall.jsonl")
_COVERAGE_VALUES = {"complete", "partial", "none"}
_MISSING_REASONS = {
    None, "knowledge_gap", "missing_user_context", "realtime_required", "external_authority_required",
}


def formal_thresholds() -> Thresholds:
    """知识正式集只门禁可完整标注的召回、排序与拒答能力。"""
    return Thresholds(
        recall=0.85, precision=None, mrr=0.85, ndcg=0.85,
        empty_accuracy=1.0, policy_rejection_accuracy=1.0,
    )


def load_dataset(path: Path) -> list[dict]:
    rows = [
        json.loads(raw)
        for raw in path.read_text(encoding="utf-8").splitlines()
        if raw.strip()
    ]
    for row in rows:
        validate_coverage_contract(row)
    return rows


def coverage_status(case: dict) -> str:
    """兼容旧评测集；新数据显式使用 complete/partial/none。"""
    value = case.get("answerability")
    if value in _COVERAGE_VALUES:
        return str(value)
    if case.get("expected_unanswerable") or value == "unanswerable":
        return "none"
    return "complete"


def validate_coverage_contract(case: dict) -> None:
    """校验 v5 覆盖契约；没有 required_information_needs 的旧数据继续兼容。"""
    needs = case.get("required_information_needs")
    if needs is None:
        return
    case_id = str(case.get("id") or case.get("query") or "unknown")
    status = coverage_status(case)
    if case.get("answerability") not in _COVERAGE_VALUES:
        raise ValueError(f"{case_id}: 新覆盖契约的 answerability 必须是 complete/partial/none")
    reason = case.get("missing_reason")
    if reason not in _MISSING_REASONS:
        raise ValueError(f"{case_id}: missing_reason 非法：{reason}")
    if status == "complete" and reason is not None:
        raise ValueError(f"{case_id}: complete 不得声明 missing_reason")
    if status != "complete" and reason is None:
        raise ValueError(f"{case_id}: partial/none 必须声明 missing_reason")
    if not isinstance(needs, list) or not needs:
        raise ValueError(f"{case_id}: required_information_needs 必须为非空数组")
    ids = [str(item.get("need_id") or "") for item in needs]
    if not all(ids) or len(ids) != len(set(ids)):
        raise ValueError(f"{case_id}: need_id 缺失或重复")
    evidence_ids = {
        str(item.get("evidence_id")) for item in (case.get("evidence_ground_truth") or [])
        if item.get("evidence_id")
    }
    available = 0
    for need in needs:
        gold = need.get("gold_evidence_ids")
        if not isinstance(gold, list):
            raise ValueError(f"{case_id}/{need.get('need_id')}: gold_evidence_ids 必须是数组")
        unknown = set(map(str, gold)) - evidence_ids
        if unknown:
            raise ValueError(f"{case_id}/{need.get('need_id')}: 引用了不存在的 evidence_id：{sorted(unknown)}")
        available += bool(gold)
    if status == "complete" and available != len(needs):
        raise ValueError(f"{case_id}: complete 要求每个 need 都有 gold evidence")
    if status == "partial" and not 0 < available < len(needs):
        raise ValueError(f"{case_id}: partial 要求部分但非全部 need 有 gold evidence")
    if status == "none" and available:
        raise ValueError(f"{case_id}: none 不得包含可用 gold evidence")


def load_baseline(path: Path | None) -> dict[str, float] | None:
    """读取知识检索的批准基线；未传时仅执行绝对门槛。"""
    if path is None:
        return None
    raw = json.loads(path.read_text(encoding="utf-8"))
    metrics = raw.get("metrics", raw)
    if not isinstance(metrics, dict):
        raise ValueError("基线文件必须是 {recall, precision, mrr, ndcg} 对象")
    return {metric: float(value) for metric, value in metrics.items()}


def source_of(item) -> str:
    """取一条检索结果所属的知识文档名。

    与 `category_insight_tool` 保持同一口径：metadata.source 缺失时退回 document_id，
    否则评测口径和线上口径会不一致。
    """
    metadata = getattr(item.chunk, "metadata", None)
    if metadata:
        return metadata.get("source", item.document_id)
    return item.document_id


def information_need_groups(case: dict, gold_evidence_ids: list[str]) -> list[set[str] | None]:
    """把冻结金标映射成必须覆盖的信息需求；不使用模型自报的 need ID 充当真值。"""
    declared_needs = case.get("required_information_needs")
    if declared_needs:
        return [
            (set(map(str, need.get("gold_evidence_ids") or [])) or None)
            for need in declared_needs
        ]
    if not gold_evidence_ids:
        return []
    evidence = case.get("evidence_ground_truth") or []
    retrievable_hop_ids = {
        hop["id"] for hop in (case.get("hops") or []) if hop.get("relevant")
    }
    hop_groups = []
    for hop_id in retrievable_hop_ids:
        group = {
            item["evidence_id"] for item in evidence
            if int(item.get("grade") or 0) >= 2 and hop_id in (item.get("supports") or [])
        }
        if group:
            hop_groups.append(group)
    if hop_groups:
        return hop_groups
    if case.get("primary_kind") == "cross_evidence":
        return [{evidence_id} for evidence_id in gold_evidence_ids]
    return [set(gold_evidence_ids)]


def information_need_coverage(
    retrieved_evidence_ids: list[str],
    groups: list[set[str] | None],
) -> float | None:
    if not groups:
        return None
    retrieved = set(retrieved_evidence_ids)
    # 同一 need 下的多个 gold evidence 是可替代支持证据：命中任意一个即可满足该 need。
    # 不同 need 仍分别计数，因此多证据问题不会被降成“任意命中一条即满分”。
    return sum(bool(group) and bool(group & retrieved) for group in groups) / len(groups)


async def run_dataset(
    knowledge_base,
    cases: list[dict],
    top_k: int,
    *,
    observations: list[dict] | None = None,
    query_processor: QueryProcessor | None = None,
    rrf_k: int = 60,
    execute_rewrite: bool = True,
    candidate_cache: dict | None = None,
    per_need_reranker=None,
    langfuse_enabled: bool = False,
    evaluation_run_id: str = "",
    evaluation_strategy: str = "",
    dataset_hash: str = "",
    repetition: int = 1,
) -> Aggregate:
    for case in cases:
        validate_coverage_contract(case)
    results: list[QueryResult] = []
    partial_results: list[QueryResult] = []
    empty_results: list[bool] = []
    policy_results: list[bool] = []
    for case in cases:
        case_trace = EvaluationCaseTrace(
            enabled=langfuse_enabled,
            run_id=evaluation_run_id,
            case_id=str(case.get("id") or "unknown"),
            strategy=evaluation_strategy or "unspecified",
            dataset_hash=dataset_hash or "unknown",
            answerability=coverage_status(case),
            missing_reason=case.get("missing_reason"),
            repetition=repetition,
            top_k=top_k,
            rrf_k=rrf_k,
        )
        started = time.perf_counter()
        try:
            outcome = await search_knowledge_with_trace(
                knowledge_base, case["query"], top_k=top_k,
                query_processor=query_processor, rrf_k=rrf_k, execute_rewrite=execute_rewrite,
                candidate_cache=candidate_cache,
                per_need_reranker=per_need_reranker,
            )
        except BaseException as error:
            case_trace.finish(error=error)
            raise
        hits = outcome.hits
        latency_ms = (time.perf_counter() - started) * 1000
        # 同一篇文档可能命中多个 chunk：按首次出现保序去重，落到文档粒度
        retrieved: list[str] = []
        for item in hits:
            src = source_of(item)
            if src not in retrieved:
                retrieved.append(src)

        relevant = case.get("relevant") or []
        case_coverage = coverage_status(case)
        expected_unanswerable = case_coverage == "none"
        evidence = case.get("evidence_ground_truth") or []
        gold_evidence_ids = [item["evidence_id"] for item in evidence if int(item.get("grade") or 0) >= 2]
        retrieved_evidence_ids, evidence_ranks = matched_evidence_ids(hits, evidence)
        raw_candidates = outcome.trace.raw_candidates or outcome.trace.candidates
        reranked_candidates = outcome.trace.reranked_candidates or outcome.trace.candidates
        raw_candidate_items = [candidate.item for candidate in raw_candidates]
        reranked_candidate_items = [candidate.item for candidate in reranked_candidates]
        fusion_candidate_items = (
            list(outcome.trace.fusion_candidates)
            or [candidate.item for candidate in outcome.trace.candidates]
        )
        candidate_items = [candidate.item for candidate in outcome.trace.candidates]
        raw_evidence_ids, _ = matched_evidence_ids(raw_candidate_items, evidence)
        reranked_evidence_ids, _ = matched_evidence_ids(reranked_candidate_items, evidence)
        fusion_evidence_ids, fusion_evidence_ranks = matched_evidence_ids(fusion_candidate_items, evidence)
        candidate_evidence_ids, _ = matched_evidence_ids(candidate_items, evidence)
        gold_set = set(gold_evidence_ids)
        raw_set = set(raw_evidence_ids)
        reranked_set = set(reranked_evidence_ids)
        fusion_set = set(fusion_evidence_ids)
        final_set = set(retrieved_evidence_ids)
        retrieval_loss_ids = sorted(gold_set - raw_set)
        reranker_loss_ids = sorted((gold_set & raw_set) - reranked_set)
        fusion_loss_ids = sorted((gold_set & reranked_set) - fusion_set)
        top_k_loss_ids = sorted((gold_set & fusion_set) - final_set)
        fusion_ranking = []
        for rank, entry in enumerate(outcome.trace.fusion_ranked, 1):
            item = entry["item"]
            metadata = getattr(getattr(item, "chunk", None), "metadata", None) or {}
            matched_ids, _ = matched_evidence_ids([item], evidence)
            fusion_ranking.append({
                "rank": rank,
                "candidate_id": entry["candidate_id"],
                "document_id": str(entry["document_id"]),
                "source": str(metadata.get("source") or entry["document_id"]),
                "section": str(metadata.get("section") or metadata.get("heading") or ""),
                "rrf_score": (
                    round(float(entry["rrf_score"]), 10)
                    if entry.get("rrf_score") is not None else None
                ),
                "ranking_score": round(float(entry["ranking_score"]), 10),
                "ranking_score_type": str(entry["ranking_score_type"]),
                "best_rank": int(entry["best_rank"]),
                "eligible": bool(entry["eligible"]),
                "selected": bool(entry["selected"]),
                "information_need_ids": sorted({
                    str(source.get("information_need_id") or "")
                    for source in entry["provenance"]
                }),
                "matched_gold_evidence_ids": matched_ids,
            })
        gold_count = len(gold_set)
        need_groups = information_need_groups(case, gold_evidence_ids)
        pre_need_coverage = information_need_coverage(candidate_evidence_ids, need_groups)
        post_need_coverage = information_need_coverage(retrieved_evidence_ids, need_groups)
        evidence_recall = (
            recall_at_k(retrieved_evidence_ids, gold_evidence_ids, len(retrieved_evidence_ids) or top_k)
            if gold_evidence_ids else None
        )
        strict_all_gold_evidence_recall = (
            float(set(gold_evidence_ids).issubset(retrieved_evidence_ids)) if gold_evidence_ids else None
        )
        all_required_needs_recall = (
            float(post_need_coverage == 1.0) if post_need_coverage is not None else None
        )
        # v5 显式 needs 按“全部需求均有至少一条有效证据”判完整；旧集继续沿用全部 gold 命中。
        all_evidence_recall = (
            all_required_needs_recall
            if case.get("required_information_needs") else strict_all_gold_evidence_recall
        )

        hard_negative_sources = [item["source"] for item in case.get("hard_negatives") or []]
        hard_negative_hit = bool(set(retrieved) & set(hard_negative_sources)) if hard_negative_sources else None
        first_negative_rank = next((i for i, src in enumerate(retrieved, 1) if src in hard_negative_sources), None)
        positive_sources = {source for source, grade in (case.get("graded_relevance") or {}).items() if grade >= 2}
        first_positive_rank = next((i for i, src in enumerate(retrieved, 1) if src in positive_sources), None)
        hard_negative_above_positive = (
            first_negative_rank is not None and (first_positive_rank is None or first_negative_rank < first_positive_rank)
            if hard_negative_sources else None
        )

        hops = case.get("hops") or []
        retrievable_hops = [hop for hop in hops if hop.get("relevant")]
        hop_scores: list[float] = []
        for hop in retrievable_hops:
            hop_evidence = [
                item["evidence_id"] for item in evidence
                if int(item.get("grade") or 0) >= 2 and hop["id"] in (item.get("supports") or [])
            ]
            if hop_evidence:
                hop_scores.append(float(set(hop_evidence).issubset(retrieved_evidence_ids)))
            else:
                hop_scores.append(float(set(hop["relevant"]).issubset(retrieved)))
        hop_recall = sum(hop_scores) / len(hop_scores) if hop_scores else None
        # 若任何 hop 属于商品检索/规划层，裸知识 runner 不能伪造端到端 Path Success。
        path_success = bool(hop_scores and all(hop_scores)) if hops and len(retrievable_hops) == len(hops) else None
        observation = {
            "case_id": case.get("id"), "query": case["query"], "split": case.get("split"),
            "answerability": case_coverage,
            "missing_reason": case.get("missing_reason"),
            "retrieved": retrieved, "relevant": relevant,
            "expected_unanswerable": expected_unanswerable,
            "unanswerable_pass": not has_answerable_knowledge(hits) if expected_unanswerable else None,
            "retrieved_evidence_ids": retrieved_evidence_ids,
            "gold_evidence_ids": gold_evidence_ids,
            "evidence_ranks": evidence_ranks,
            "evidence_recall": evidence_recall,
            "available_evidence_recall": evidence_recall if case_coverage == "partial" else None,
            "all_evidence_recall": all_evidence_recall if case_coverage == "complete" else None,
            "strict_all_gold_evidence_recall": strict_all_gold_evidence_recall,
            "all_required_needs_recall": all_required_needs_recall,
            "hard_negative_hit": hard_negative_hit,
            "hard_negative_above_positive": hard_negative_above_positive,
            "hop_recall": hop_recall,
            "path_success": path_success,
            "constraint_recall": None,
            "latency_ms": round(latency_ms, 3),
            "query_processor_stage_latency_ms": outcome.trace.query_processor_latency_ms,
            "retrieval_stage_latency_ms": outcome.trace.retrieval_latency_ms,
            "reranker_stage_latency_ms": outcome.trace.reranker_latency_ms,
            "fusion_stage_latency_ms": outcome.trace.fusion_latency_ms,
            "retrieval_mode": outcome.trace.mode,
            "processor_plan_mode": outcome.trace.processor_plan_mode,
            "effective_plan_mode": outcome.trace.effective_plan_mode,
            "query_plan_mode": outcome.trace.query_plan_mode,
            "query_variants": outcome.trace.variants,
            "rewrite_similarity": outcome.trace.rewrite_similarity,
            "rewrite_decision": outcome.trace.rewrite_decision,
            "near_duplicate_decisions": outcome.trace.near_duplicate_decisions,
            "fusion_provenance": outcome.trace.fused,
            "per_need_rerank_applied": outcome.trace.per_need_rerank_applied,
            "per_need_rerank_calls": outcome.trace.per_need_rerank_calls,
            "query_processor_latency_ms": outcome.trace.query_processor_latency_ms,
            "query_processor_usage": outcome.trace.query_processor_usage,
            "candidate_count": len(outcome.trace.candidates),
            "processor_fallback_reason": outcome.trace.processor_fallback_reason,
            "pre_fusion_query_route_coverage": outcome.trace.pre_fusion_query_route_coverage,
            "post_fusion_query_route_coverage": outcome.trace.post_fusion_query_route_coverage,
            "pre_fusion_information_need_coverage": pre_need_coverage,
            "post_fusion_information_need_coverage": post_need_coverage,
            "missing_need_detected": None,
            "false_complete_answer": None,
            "correct_escalation": None,
            "fusion_information_need_loss": (
                None
                if pre_need_coverage is None or post_need_coverage is None
                else round(pre_need_coverage - post_need_coverage, 4)
            ),
            "pre_fusion_retrieved_evidence_ids": candidate_evidence_ids,
            "raw_retrieval_evidence_ids": raw_evidence_ids,
            "post_rerank_evidence_ids": reranked_evidence_ids,
            "post_fusion_evidence_ids": fusion_evidence_ids,
            "post_fusion_evidence_ranks": fusion_evidence_ranks,
            "post_fusion_ranking": fusion_ranking,
            "final_top_k_evidence_ids": retrieved_evidence_ids,
            "evidence_stage_presence": {
                evidence_id: {
                    "raw_retrieval": evidence_id in raw_set,
                    "post_rerank": evidence_id in reranked_set,
                    "post_fusion": evidence_id in fusion_set,
                    "final_top_k": evidence_id in final_set,
                }
                for evidence_id in gold_evidence_ids
            },
            "retrieval_loss_evidence_ids": retrieval_loss_ids,
            "reranker_loss_evidence_ids": reranker_loss_ids,
            "fusion_loss_evidence_ids": fusion_loss_ids,
            "top_k_truncation_loss_evidence_ids": top_k_loss_ids,
            "retrieval_loss_rate": len(retrieval_loss_ids) / gold_count if gold_count else None,
            "reranker_loss_rate": len(reranker_loss_ids) / gold_count if gold_count else None,
            "fusion_loss_rate": len(fusion_loss_ids) / gold_count if gold_count else None,
            "top_k_truncation_loss_rate": len(top_k_loss_ids) / gold_count if gold_count else None,
        }
        observation["langfuse_trace_id"] = case_trace.finish(result_attributes(observation))
        observation["evaluation_run_id"] = evaluation_run_id or None
        if observations is not None:
            observations.append(observation)
        if expected_unanswerable:
            # Qdrant 即使没有语义证据也会给出“最近邻”；必须按可回答阈值拒答。
            empty_results.append(not has_answerable_knowledge(hits))
            continue
        if case.get("expected_behavior"):
            statuses = [
                policy_fact_status(getattr(item.chunk, "metadata", None) or {})
                for item in hits
                if source_of(item) in relevant
            ]
            # 命中目标政策文档且每条都被标为不可作确定事实，才算具备可执行拒答证据。
            policy_results.append(bool(statuses) and all(status != "fact_eligible" for status in statuses))
            observation.update(policy_statuses=statuses, policy_pass=policy_results[-1])
        query_result = QueryResult(
                query=case["query"],
                retrieved=retrieved,
                relevant=relevant,
                recall=recall_at_k(retrieved, relevant, top_k),
                mrr=mrr(retrieved, relevant),
                ndcg=ndcg_at_k(retrieved, relevant, top_k),
                precision=precision_at_k(retrieved, relevant, top_k),
                kind=case.get("kind", "knowledge"),
                dimensions={
                    "split": str(case.get("split") or "ALL"),
                    "primary_kind": str(case.get("primary_kind") or case.get("original_kind") or case.get("kind") or "knowledge"),
                    "query_plan_mode": str(outcome.trace.query_plan_mode or outcome.trace.mode),
                    "answerability": case_coverage,
                    "missing_reason": str(case.get("missing_reason") or "none"),
                },
                latency_ms=latency_ms,
                evidence_recall=evidence_recall,
                all_evidence_recall=all_evidence_recall if case_coverage == "complete" else None,
                hop_recall=hop_recall,
                path_success=path_success,
                constraint_recall=None,
                hard_negative_hit=hard_negative_hit,
                hard_negative_above_positive=hard_negative_above_positive,
                graded_ndcg=(
                    graded_ndcg_at_k(retrieved, case.get("graded_relevance") or {}, top_k)
                    if case.get("graded_relevance") else None
                ),
                pre_fusion_information_need_coverage=pre_need_coverage,
                post_fusion_information_need_coverage=post_need_coverage,
                available_evidence_recall=evidence_recall if case_coverage == "partial" else None,
                information_need_coverage=post_need_coverage if case_coverage == "partial" else None,
            )
        if case_coverage == "partial":
            partial_results.append(query_result)
        else:
            results.append(query_result)
    aggregate = evaluate(results, k=top_k, empty_results=empty_results, policy_results=policy_results)
    return attach_partial_coverage_metrics(aggregate, partial_results)


def render_report(
    agg: Aggregate,
    thresholds: Thresholds,
    baseline: dict[str, float] | None = None,
    dataset: Path | str = _DATASET,
) -> str:
    verdict, reasons = gate(agg, thresholds, baseline)
    lines = [
        f"# 品类知识库召回评测报告（{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}）",
        "",
        f"标注集 `{dataset}`，正例 {agg.count} 条。兼容文档级指标；存在 evidence_ground_truth 时同时按原文证据评分。",
        "v5 显式 required_information_needs 的完整正确口径是：每个 need 至少命中一条有效 gold，而不是把同一 need 的替代证据全部塞入 Top-K。",
        "",
        f"| 指标 | 值 | 阈值 |",
        "|---|---|---|",
        f"| Recall@{agg.k} | {agg.recall:.3f} | ≥ {thresholds.recall}（阻断） |",
        f"| Precision@{agg.k} | {agg.precision:.3f} | "
        f"{('观察项（未穷举金标，不阻断）' if thresholds.precision is None else f'≥ {thresholds.precision}（阻断）')} |",
        f"| MRR | {agg.mrr:.3f} | ≥ {thresholds.mrr}（阻断） |",
        f"| NDCG@{agg.k} | {agg.ndcg:.3f} | ≥ {thresholds.ndcg}（阻断） |",
        f"| Graded nDCG@{agg.k} | {'n/a' if agg.graded_ndcg is None else f'{agg.graded_ndcg:.3f}'} | 0–3 级相关性，观察项 |",
        f"| 不可回答准确率 | {'n/a' if agg.empty_accuracy is None else f'{agg.empty_accuracy:.3f}'} | "
        f"{('未启用' if thresholds.empty_accuracy is None else f'≥ {thresholds.empty_accuracy}（阻断）') } |",
        f"| 政策拒答准确率 | {'n/a' if agg.policy_rejection_accuracy is None else f'{agg.policy_rejection_accuracy:.3f}'} | "
        f"{('未启用' if thresholds.policy_rejection_accuracy is None else f'≥ {thresholds.policy_rejection_accuracy}（阻断）') } |",
        f"| Evidence Recall | {'n/a' if agg.evidence_recall is None else f'{agg.evidence_recall:.3f}'} | 观察项 |",
        f"| All-evidence Recall | {'n/a' if agg.all_evidence_recall is None else f'{agg.all_evidence_recall:.3f}'} | 观察项 |",
        f"| Hard-negative hit rate | {'n/a' if agg.hard_negative_hit_rate is None else f'{agg.hard_negative_hit_rate:.3f}'} | 越低越好 |",
        f"| Hard negative 高于正证据 | {'n/a' if agg.hard_negative_above_positive_rate is None else f'{agg.hard_negative_above_positive_rate:.3f}'} | 越低越好 |",
        f"| Hop Recall | {'n/a' if agg.hop_recall is None else f'{agg.hop_recall:.3f}'} | 仅知识检索可验证 hop |",
        f"| Path Success | {'n/a' if agg.path_success_rate is None else f'{agg.path_success_rate:.3f}'} | 跨工具 hop 未接 Planner 时为 n/a |",
        f"| Constraint Recall | {'n/a' if agg.constraint_recall is None else f'{agg.constraint_recall:.3f}'} | 未接 Planner/trace 时为 n/a |",
        f"| Pre-fusion information-need coverage | {'n/a' if agg.pre_fusion_information_need_coverage is None else f'{agg.pre_fusion_information_need_coverage:.3f}'} | 子查询候选池覆盖率 |",
        f"| Post-fusion information-need coverage | {'n/a' if agg.post_fusion_information_need_coverage is None else f'{agg.post_fusion_information_need_coverage:.3f}'} | 最终 Top-K 覆盖率 |",
        f"| Fusion information-need loss | {'n/a' if agg.fusion_information_need_loss is None else f'{agg.fusion_information_need_loss:.3f}'} | 越低越好 |",
        f"| Partial: Available Evidence Recall | {'n/a' if agg.available_evidence_recall is None else f'{agg.available_evidence_recall:.3f}'} | 只评价 KB 已有证据 |",
        f"| Partial: Information Need Coverage | {'n/a' if agg.partial_information_need_coverage is None else f'{agg.partial_information_need_coverage:.3f}'} | 分母包含缺失 need |",
        f"| Partial: Missing Need Detection | {'n/a' if agg.missing_need_detection_accuracy is None else f'{agg.missing_need_detection_accuracy:.3f}'} | 需要 Agent 最终回答 trace |",
        f"| Partial: False Complete Answer Rate | {'n/a' if agg.false_complete_answer_rate is None else f'{agg.false_complete_answer_rate:.3f}'} | 越低越好；需要 Agent 最终回答 trace |",
        f"| Partial: Correct Escalation Rate | {'n/a' if agg.correct_escalation_rate is None else f'{agg.correct_escalation_rate:.3f}'} | 需要 Agent 最终动作 trace |",
        "",
        f"门禁结论：**{verdict}**",
        "",
    ]
    if reasons:
        lines += ["未达标项：", *[f"- {r}" for r in reasons], ""]
    if agg.bucket_metrics:
        lines += ["## 分桶指标", "", "| 桶 | 数量 | Recall/拒答准确率 | MRR | NDCG | Graded nDCG | Evidence Recall | All-evidence | Hop Recall | Pre-need | Post-need |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for name, bucket in agg.bucket_metrics.items():
            score = bucket.get("recall", bucket.get("rejection_accuracy"))
            fmt = lambda value: "n/a" if value is None else f"{float(value):.3f}"
            lines.append(
                f"| {name} | {bucket.get('count', 0)} | {fmt(score)} | {fmt(bucket.get('mrr'))} | "
                f"{fmt(bucket.get('ndcg'))} | {fmt(bucket.get('graded_ndcg'))} | {fmt(bucket.get('evidence_recall'))} | "
                f"{fmt(bucket.get('all_evidence_recall'))} | {fmt(bucket.get('hop_recall'))} | "
                f"{fmt(bucket.get('pre_fusion_information_need_coverage'))} | {fmt(bucket.get('post_fusion_information_need_coverage'))} |"
            )
        lines.append("")
    lines += ["| query | Recall | Precision | MRR | NDCG | 召回文档 | 标注文档 |", "|---|---|---|---|---|---|---|"]
    for r in agg.per_query:
        lines.append(
            f"| {r.query} | {r.recall:.2f} | {r.precision:.2f} | {r.mrr:.2f} | {r.ndcg:.2f} | "
            f"{','.join(r.retrieved) or '（空）'} | {','.join(r.relevant)} |",
        )
    if agg.partial_per_query:
        lines += [
            "",
            "## Partial Coverage 专项",
            "",
            "裸检索只能验证已有证据召回和 information need 覆盖；缺失识别、假装完整回答和升级动作必须由端到端 Agent runner 评测。",
            "",
            "| query | Available Evidence Recall | Information Need Coverage | 召回文档 |",
            "|---|---:|---:|---|",
        ]
        for result in agg.partial_per_query:
            available = "n/a" if result.available_evidence_recall is None else f"{result.available_evidence_recall:.2f}"
            coverage = "n/a" if result.information_need_coverage is None else f"{result.information_need_coverage:.2f}"
            lines.append(f"| {result.query} | {available} | {coverage} | {','.join(result.retrieved) or '（空）'} |")
    return "\n".join(lines) + "\n"


async def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="品类知识库召回评测")
    parser.add_argument("--dataset", default=str(_DATASET))
    parser.add_argument("--split", choices=SPLITS, default="all", help="仅执行选中的 dev/release；默认 all 兼容旧集")
    parser.add_argument("--dry-run", action="store_true", help="只校验选集并写 NOT_RUN 证据，不调用 embedding/Qdrant")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument(
        "--strategy", choices=("legacy", "query-transform", "query-decompose"), default="legacy",
        help=("legacy=冻结旧链路；query-transform=V2 原样执行；"
              "query-decompose=复用 V2 计划，但把 REWRITE 映射为 DIRECT"),
    )
    parser.add_argument("--rrf-k", type=int, default=60, help="query-transform 的 RRF rank constant")
    parser.add_argument("--min-recall", type=float, default=0.75)
    parser.add_argument("--min-precision", type=float, default=0.45)
    parser.add_argument("--min-mrr", type=float, default=0.65)
    parser.add_argument("--min-ndcg", type=float, default=0.70)
    parser.add_argument("--min-unanswerable-accuracy", type=float, default=None)
    parser.add_argument("--formal-gates", action="store_true", help="启用正式知识集门槛：K=3、Recall/MRR/NDCG≥0.85、不可回答=100%%")
    parser.add_argument("--baseline-file", type=Path, default=None, help="批准基线 JSON；指标下降超过 2 个百分点即阻断")
    parser.add_argument("--report-dir", default="eval")
    parser.add_argument(
        "--langfuse", action="store_true",
        help="把脱敏后的逐题评测 trace 发到 Langfuse；不上传 query 或知识正文",
    )
    args = parser.parse_args(argv)
    try:
        cases, selection = select_cases(load_dataset(Path(args.dataset)), args.split)
        validate_baseline_selection(args.baseline_file, selection, Path(args.dataset))
    except (ValueError, OSError) as err:
        parser.error(str(err))
    top_k = 3 if args.formal_gates else args.top_k
    if top_k <= 0:
        parser.error("--top-k 必须为正整数")
    print(f"标注集 {args.dataset}：split={args.split}，{len(cases)} 条，K={top_k}")
    thresholds = (
        formal_thresholds()
        if args.formal_gates
        else Thresholds(
            recall=args.min_recall, precision=args.min_precision, mrr=args.min_mrr,
            ndcg=args.min_ndcg, empty_accuracy=args.min_unanswerable_accuracy,
        )
    )
    baseline = load_baseline(args.baseline_file)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"category-recall-{args.split}-report-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.md"
    manifest = build_manifest(
        runner="category_recall", dataset=Path(args.dataset), selection=selection, baseline=args.baseline_file,
        parameters={"formal_gates": args.formal_gates, "top_k": top_k, "thresholds": thresholds,
                    "requested_strategies": [args.strategy], "rrf_k": args.rrf_k, "dry_run": args.dry_run,
                    "langfuse_enabled": args.langfuse,
                    "gate_scope": "release" if args.split == "release" and args.formal_gates else "diagnostic"},
    )
    if args.dry_run:
        path = write_manifest(manifest, report_path)
        print(f"仅校验选集：NOT_RUN；未计算指标、未判定通过。证据：{path}")
        return
    observations: list[dict] = []
    try:
        settings = load_settings()
        if args.langfuse:
            LangfuseConfig(
                settings.langfuse_base_url, settings.langfuse_public_key, settings.langfuse_secret_key,
            ).validate()
            setup_tracing(settings)
        evaluation_run_id = f"knowledge-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:8]}"
        dataset_hash = hashlib.sha256(Path(args.dataset).read_bytes()).hexdigest()
        knowledge_base = build_evaluation_knowledge_base(settings)
        document_count = await verify_evaluation_knowledge_base(knowledge_base, EVALUATION_KNOWLEDGE_DIR)
        print(f"冻结评测知识库就绪（{document_count} 篇；未执行自动重建）")
        query_processor = None
        if args.strategy in {"query-transform", "query-decompose"}:
            processor_settings = replace(
                settings,
                llm_base_url=settings.query_processor_base_url or settings.llm_base_url,
                llm_api_key=settings.query_processor_api_key or settings.llm_api_key,
                llm_model=settings.query_processor_model or settings.llm_model,
                llm_fallback_model="",
            )
            query_processor = QueryProcessor(
                create_chat_model(processor_settings, stream=False),
                load_prompts()["query_processor"]["system_prompt"],
                max_subqueries=settings.query_processor_max_subqueries,
                disable_thinking=settings.query_processor_disable_thinking,
            )
        agg = await run_dataset(
            knowledge_base, cases, top_k, observations=observations,
            query_processor=query_processor, rrf_k=args.rrf_k,
            execute_rewrite=args.strategy != "query-decompose",
            langfuse_enabled=args.langfuse, evaluation_run_id=evaluation_run_id,
            evaluation_strategy=args.strategy, dataset_hash=dataset_hash,
        )
    except Exception as err:
        actual = sorted({item.get("retrieval_mode") for item in observations if item.get("retrieval_mode")})
        finish_manifest(manifest, actual_strategies=actual, gate="BLOCK", status="ERROR", observations=observations, error=f"{type(err).__name__}: {err}")
        write_manifest(manifest, report_path)
        report_path.write_text(f"# 品类知识库评测未完成\n\n{type(err).__name__}: {err}" + manifest_report(manifest), encoding="utf-8")
        print(f"执行失败，已保存 BLOCK 证据：{report_path}")
        if args.langfuse:
            shutdown_tracing()
        raise SystemExit(1) from err
    print(
        f"  Recall@{agg.k}={agg.recall:.3f}  Precision@{agg.k}={agg.precision:.3f}  MRR={agg.mrr:.3f}  "
        f"NDCG@{agg.k}={agg.ndcg:.3f}  不可回答准确率={'n/a' if agg.empty_accuracy is None else f'{agg.empty_accuracy:.3f}'}  "
        f"政策拒答准确率={'n/a' if agg.policy_rejection_accuracy is None else f'{agg.policy_rejection_accuracy:.3f}'}",
    )

    verdict, reasons = gate(agg, thresholds, baseline)
    actual = sorted({item.get("retrieval_mode") for item in observations if item.get("retrieval_mode")})
    stable = finish_manifest(manifest, actual_strategies=actual, gate=verdict, metrics=agg, observations=observations, reasons=reasons)
    write_manifest(manifest, report_path)
    report_path.write_text(render_report(agg, thresholds, baseline, dataset=Path(args.dataset)) + manifest_report(manifest), encoding="utf-8")
    if args.langfuse:
        shutdown_tracing()
    print(f"报告已写入 {report_path}")

    print(f"最终门禁：{manifest['execution']['gate']}" + (f"（{'；'.join(reasons)}）" if reasons else ""))
    if not stable:
        print("阻断原因：运行期间代码或数据输入发生变化，需在固定版本上重跑。")
    if verdict == "BLOCK" or not stable:
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
