# -*- coding: utf-8 -*-
"""SearchAgent

跨境商品检索专家。基于 AgentScope 2.0 Agent：
    工具集：product_search_tool（embedding+rerank 二阶段召回）
          category_insight_tool（品类洞察 RAG，选购常识）
          web_search_tool（可选，跨境政策兜底）

对外通过 task_dispatch 工具被 MainAgent 调度（SubAgent as Tool 模式）。
每次调度新建独立实例：2.0 的对话上下文内建于 AgentState，独立实例天然上下文隔离。
`build_tools()` 同时供 MainAgent 复用——主 Agent 持有同一批业务工具，可以不派发自己单干。
"""
from __future__ import annotations
from dataclasses import replace
from app.infrastructure.context_governance import ContextAwareAgent

from agentscope.agent import Agent, ReActConfig
from agentscope.rag import KnowledgeBase
from agentscope.tool import FunctionTool, Toolkit

from app.application.agents.context_policy import build_context_config
from app.application.prompts.loader import load_prompts
from app.application.tools.category_insight_tool import build_category_insight_tool
from app.application.tools.product_search_tool import build_product_search_tool
from app.application.tools.web_search_tool import build_web_search_tool
from app.application.tools.conversation_fact_lookup import build_conversation_fact_lookup
from app.infrastructure.persistence.context_evidence import ContextEvidenceStore
from app.application.usecases.catalog_search import CatalogSearchUseCase
from app.infrastructure.eventbus import TradeEventBus
from app.infrastructure.rag.category_knowledge import KNOWLEDGE_DIR
from app.infrastructure.llm import create_chat_model
from app.infrastructure.throttle import GatewayThrottle
from app.infrastructure.resilience import (
    CircuitBreakerRegistry,
    ToolResilienceMiddleware,
)
from app.infrastructure.settings import Settings
from app.infrastructure.tracing import build_agent_middlewares
from app.application.retrieval.query_processor import QueryProcessor
from app.application.harness.assertions import SequencingTracker
from app.application.harness.loop_detector import LoopDetector
from app.infrastructure.harness_middleware import HarnessToolMiddleware


class SearchAgentFactory:
    def __init__(
        self,
        settings: Settings,
        catalog_search: CatalogSearchUseCase,
        bus: TradeEventBus,
        knowledge_base: KnowledgeBase,
        circuit_registry: CircuitBreakerRegistry,
        throttle: GatewayThrottle,
        knowledge_reranker=None,
        throttle_factory=None,
    ) -> None:
        self._settings = settings
        self._catalog_search = catalog_search
        self._bus = bus
        self._knowledge_base = knowledge_base
        self._circuit_registry = circuit_registry
        # 闸门由组装根下发，三个工厂必须共用同一个，否则各限一份等于没限
        self._throttle = throttle
        # 与商品召回复用同一受控 HTTP reranker；知识链路只在 DECOMPOSE
        # 时按 information need 分别调用，DIRECT 不增加精排请求。
        self._knowledge_reranker = knowledge_reranker
        self.evidence_store = ContextEvidenceStore(settings.data_dir / "context_evidence.db")
        self._query_processor_model = None
        if settings.knowledge_query_transform_enabled:
            processor_settings = replace(
                settings,
                llm_base_url=settings.query_processor_base_url or settings.llm_base_url,
                llm_api_key=settings.query_processor_api_key or settings.llm_api_key,
                llm_model=settings.query_processor_model or settings.llm_model,
                # QueryProcessor 故障由知识检索精确回退 legacy，不再切换另一模型产生第二套改写。
                llm_fallback_model="",
            )
            self._query_processor_model = create_chat_model(
                processor_settings, stream=False, throttle=throttle, bus=bus,
            )
        self._throttle_factory = throttle_factory
        self.bind_harness(SequencingTracker(), LoopDetector(repeat_threshold=settings.loop_repeat_threshold))

    def bind_harness(self, sequencing, loop_detector) -> None:
        """主 Agent 和子 Agent 共用会话护栏，避免派发后重新计数。"""
        self._sequencing, self._loop_detector = sequencing, loop_detector

    def _resilience(self) -> list:
        chain = [HarnessToolMiddleware(sequencing=self._sequencing,
            loop_detector=self._loop_detector, bus=self._bus)] if self._settings.harness_enabled else []
        return [*chain, ToolResilienceMiddleware(self._circuit_registry, self._bus)]

    def build_tools(self) -> list[FunctionTool]:
        """SearchAgent 的业务工具集，MainAgent 单干时持有同一批（均带超时+熔断保护）。

        web_search_tool 按"有 TAVILY_API_KEY 才注册"设计，未配置时 Agent 看不到它。
        """
        prompts = load_prompts()
        query_processor = (
            QueryProcessor(
                self._query_processor_model,
                prompts["query_processor"]["system_prompt"],
                max_subqueries=self._settings.query_processor_max_subqueries,
                disable_thinking=self._settings.query_processor_disable_thinking,
            )
            if self._query_processor_model is not None else None
        )
        tools = [
            FunctionTool(
                build_product_search_tool(self._catalog_search, self._bus, self.evidence_store, self._settings.context_strategy),
                is_read_only=True,
                middlewares=self._resilience(),
            ),
            FunctionTool(
                build_category_insight_tool(
                    self._knowledge_base,
                    self._bus,
                    fallback_knowledge_dir=KNOWLEDGE_DIR,
                    query_processor=query_processor,
                    rrf_k=self._settings.knowledge_rrf_k,
                    per_need_reranker=self._knowledge_reranker,
                ),
                is_read_only=True,
                middlewares=self._resilience(),
            ),
        ]
        tools.append(FunctionTool(build_conversation_fact_lookup(self.evidence_store, mode=self._settings.context_lookup_mode), is_read_only=True,
                                  middlewares=self._resilience()))
        if self._settings.tavily_api_key:
            tools.append(
                FunctionTool(
                    build_web_search_tool(self._settings, self._bus),
                    is_read_only=True,
                    middlewares=self._resilience(),
                ),
            )
        return tools

    def build(self) -> Agent:
        prompts = load_prompts()["sub_agents"]["search"]
        return ContextAwareAgent(
            name=prompts["name"],
            system_prompt=prompts["system_prompt"],
            model=create_chat_model(self._settings, throttle=self._throttle, bus=self._bus, throttle_factory=self._throttle_factory),
            toolkit=Toolkit(tools=list(self.build_tools())),
            middlewares=build_agent_middlewares(self._settings),
            context_config=build_context_config(
                self._settings.context_size,
                self._settings.tool_result_limit,
            ),
            react_config=ReActConfig(max_iters=6),
        )
